from slyguy import settings

def run():
    settings.open()