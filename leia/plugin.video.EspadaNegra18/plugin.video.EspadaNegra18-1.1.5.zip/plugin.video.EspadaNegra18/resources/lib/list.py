[
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Brasil 1[/COLOR]",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegrabrasil1.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "3ad99ef9-eb57-4e87-ab18-dbbb9b9ffa7b"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Brasil 2[/COLOR]",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegrabrasil2.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a56a8001-e0e2-4b7b-89af-42d8b7b539be"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Brasil 3[/COLOR]",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegrabrasil3.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "4f03df0c-ab79-4bf3-8860-a4a7a22e1a1b"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Portugal 4[/COLOR]",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegraportugal1.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "f553a446-b2a8-4067-a20b-bd45361da911"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Portugal 5[/COLOR]",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegraportugal2.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Creditos Pluto TV[/COLOR] ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-plutotv.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Mundial TV [/COLOR]",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-mundial-tv.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Desporto TV[/COLOR] ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-desporto.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Filmes PT[/COLOR] ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-filmes-PT.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    }, 
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Filmes BR [/COLOR]",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-filmes-br.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "3ad99ef9-eb57-4e87-ab18-dbbb9b9ffa7b"
    },
    {
        "name": "[B][COLOR silver]Espada[/COLOR] [COLOR dimgrey]Negra[/COLOR][/B][COLOR orange] | [/COLOR][COLOR orange]Series [/COLOR]",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-series.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "3ad99ef9-eb57-4e87-ab18-dbbb9b9ffa7b"
    }    
]