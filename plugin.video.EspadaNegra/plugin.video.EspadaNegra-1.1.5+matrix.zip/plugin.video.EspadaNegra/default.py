# -*- coding: UTF-8 -*-
try :
 import urllib . parse as urllib
except ImportError :
 import urllib
try :
 import urllib2
except ImportError :
 import urllib . request as urllib2
import re
import os
import sys
try :
 import cookielib
except ImportError :
 import http . cookiejar as cookielib
from urllib import request as urllib2 , parse as urllib
import datetime
from datetime import datetime
if 64 - 64: i11iIiiIii
import re
import os
import sys
import hashlib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
import urllib . error
import urllib . parse
import urllib . parse
import urllib . request
import uuid as random
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
import xbmcaddon
import xbmcgui
import xbmcplugin
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
import resources . lib . common as common
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
import base64
import codecs
import xbmc
if 46 - 46: ooOoO0o * I11i - OoooooooOO
import xbmcaddon
import xbmcvfs
import traceback
import time
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
import webbrowser
import platform
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
OOoO = 'plugin.video.EspadaNegra'
OOo = xbmcaddon . Addon ( OOoO )
Ii1IIii11 = OOo . getAddonInfo ( "name" )
Oooo0000 = OOo . getAddonInfo ( 'icon' )
i11 = OOo . getAddonInfo ( 'path' )
I11 = i11 + '/fanart.jpg'
Oo0o0000o0o0 = i11 + '/icon.jpg'
if 86 - 86: OoOoOO00 % I1IiiI
if 80 - 80: OoooooooOO . I1IiiI
OOO0O = OOo . getAddonInfo ( 'path' )
oo0ooO0oOOOOo = os . path . join ( OOO0O , "resources" , "images" )
if 71 - 71: I1Ii111
O0OoOoo00o = os . path . join ( OOO0O , 'resources' , 'lib' )
sys . path . insert ( 0 , O0OoOoo00o )
import common
if 31 - 31: II111iiii + OoO0O00 . I1Ii111
OoOooOOOO = xbmcvfs . translatePath ( OOo . getAddonInfo ( "profile" ) )
i11iiII = os . path . join ( OoOooOOOO , "cache" )
if not os . path . exists ( i11iiII ) :
 os . makedirs ( i11iiII )
 if 34 - 34: OOooOOo % OoooooooOO / i1IIi . iII111i + O0
I1Ii = os . path . join ( OOO0O , "resources" , "lib" , "list.py" )
o0oOo0Ooo0O = os . path . join ( OoOooOOOO , "virtual_directoriesLists.txt" )
OO00O0O0O00Oo = os . path . join ( OoOooOOOO , 'tempList.txt' )
IIIiiiiiIii = os . path . join ( OoOooOOOO , 'favorites.txt' )
if 70 - 70: OoO0O00 . OoO0O00 - OoO0O00 / I1ii11iIi11i * OOooOOo
if not ( os . path . isfile ( IIIiiiiiIii ) ) :
 common . SaveList ( IIIiiiiiIii , [ ] )
 if 86 - 86: i11iIiiIii + Ii1I + ooOoO0o * I11i + o0oOOo0O0Ooo
if not ( os . path . isfile ( o0oOo0Ooo0O ) ) :
 common . SaveList ( o0oOo0Ooo0O , [ ] )
 if 61 - 61: OoO0O00 / i11iIiiIii
IiIiIi = OOo . getSetting ( "makeGroups" ) == "true"
if 40 - 40: oO0o . OoOoOO00 . Oo0Ooo . i1IIi
if 33 - 33: Ii1I + II111iiii % i11iIiiIii . ooOoO0o - I1IiiI
def O00oooo0O ( id ) :
 return OOo . getLocalizedString ( id )
 if 22 - 22: OoooooooOO % I11i - iII111i . iIii1I11I1II1 * i11iIiiIii
 if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . IiII
def o0OOOOO00o0O0 ( chList , addToVdir = True ) :
 if 71 - 71: ooOoO0o % iII111i / o0oOOo0O0Ooo
 ii11i1iIII = [ ]
 Ii1IOo0o0 = 0
 if 49 - 49: oO0o % Ii1I + i1IIi . I1IiiI % I1ii11iIi11i
 for I1i1iii in chList :
  i1iiI11I = 1 if '.plx' in I1i1iii [ "url" ] else 2
  iiii = common . GetEncodeString ( I1i1iii [ "name" ] )
  if 54 - 54: I1ii11iIi11i * OOooOOo
  I1IIIii = I1i1iii . get ( 'image' , '' )
  oOoOooOo0o0 = I1i1iii [ "uuid" ]
  if 61 - 61: o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * oO0o / oO0o
  if I1IIIii == "" or I1IIIii is None :
   I1IIIii = os . path . join ( oo0ooO0oOOOOo , "default-list-image.jpg" )
   if 75 - 75: i1IIi / OoooooooOO - O0 / OoOoOO00 . II111iiii - i1IIi
  O000OO0 = I1i1iii . get ( 'logos' , '' )
  I11iii1Ii = I1i1iii . get ( 'cache' , '0' )
  if I1i1iii [ "url" ] . startswith ( 'http' ) :
   ii11i1iIII . append ( hashlib . md5 ( I1i1iii [ "url" ] . encode ( ) ) . hexdigest ( ) )
  I1IIiiIiii ( "{0}" . format ( iiii ) , I1i1iii [ "url" ] , i1iiI11I , I1IIIii , O000OO0 , index = Ii1IOo0o0 , uuid = oOoOooOo0o0 , cacheMin = I11iii1Ii , addToVdir = addToVdir )
  Ii1IOo0o0 += 1
  if 97 - 97: ooOoO0o - OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - OoooooooOO
 for OoOo00o in os . listdir ( i11iiII ) :
  o0OOoo0OO0OOO = os . path . join ( i11iiII , OoOo00o )
  try :
   if os . path . isfile ( o0OOoo0OO0OOO ) and OoOo00o not in ii11i1iIII :
    os . unlink ( o0OOoo0OO0OOO )
  except Exception as iI1iI1I1i1I :
   xbmc . log ( "{0}" . format ( iI1iI1I1i1I ) , 3 )
   if 24 - 24: I1ii11iIi11i
   if 56 - 56: ooOoO0o
   if 92 - 92: iII111i . I11i + o0oOOo0O0Ooo
def IiII1I11i1I1I ( ) :
 I1IIiiIiii ( "[B][COLOR dimgrey]||[/COLOR][COLOR crimson]||[/COLOR][COLOR dimgrey]||[/COLOR][COLOR orange] BEM VINDOS [/COLOR][COLOR dimgrey]||[/COLOR][COLOR crimson]||[/COLOR][COLOR dimgrey]||[/COLOR][/B]{0}" . format ( O00oooo0O ( 0 ) ) , "BEM VINDOS" , 52 , os . path . join ( oo0ooO0oOOOOo , "bright_yellow_star.jpg" ) )
 if 83 - 83: I1ii11iIi11i / ooOoO0o
 I1IIiiIiii ( "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]{0}" . format ( O00oooo0O ( 30003 ) ) , "favorites" , 30 , os . path . join ( oo0ooO0oOOOOo , "bright_yellow_star.jpg" ) )
 if 49 - 49: o0oOOo0O0Ooo
 if 35 - 35: OoOoOO00 - OoooooooOO / I1ii11iIi11i % i1IIi
 o00OO00OoO = common . ReadList ( o0oOo0Ooo0O )
 OOOO0OOoO0O0 = 0
 for O0Oo000ooO00 in o00OO00OoO :
  oO0 = O0Oo000ooO00 [ "icon" ] if not O0Oo000ooO00 [ "icon" ] == "" else os . path . join ( oo0ooO0oOOOOo , "default-folder-image.jpg" )
  I1IIiiIiii ( "[COLOR lime][B]{0}[/B][/COLOR]" . format ( O0Oo000ooO00 [ "name" ] ) , "{0}" . format ( OOOO0OOoO0O0 ) , 44 , oO0 , uuid = O0Oo000ooO00 [ "uuid" ] , isFolder = True )
  OOOO0OOoO0O0 += 1
  if 45 - 45: i11iIiiIii * II111iiii % iIii1I11I1II1 + I1ii11iIi11i - Ii1I
 iIi1iIiii111 = [ ]
 for iIIIi1 in o00OO00OoO :
  if len ( iIIIi1 [ "data" ] ) > 0 :
   iIi1iIiii111 += iIIIi1 [ "data" ]
   if 20 - 20: i1IIi + I1ii11iIi11i - ooOoO0o
 Ii1IOo0o0 = 0
 IiI11iII1 = common . ReadList ( I1Ii )
 IIII11I1I = [ ]
 try :
  for OOO0o in IiI11iII1 :
   if "uuid" in OOO0o and not OOO0o [ "uuid" ] in iIi1iIiii111 :
    IIII11I1I . append ( IiI11iII1 [ Ii1IOo0o0 ] )
   Ii1IOo0o0 += 1
 except :
  IIII11I1I = IiI11iII1
  if 30 - 30: iIii1I11I1II1 / ooOoO0o - I1Ii111 - II111iiii % iII111i
 o0OOOOO00o0O0 ( IIII11I1I )
 if 49 - 49: I1IiiI % ooOoO0o . ooOoO0o . I11i * ooOoO0o
 I1IIiiIiii ( "[B]{0}: {1}[/B] - {2} " . format ( O00oooo0O ( 30036 ) , O00oooo0O ( 30037 ) if IiIiIi else O00oooo0O ( 30038 ) , O00oooo0O ( 30039 ) ) , "setting" , 50 , os . path . join ( oo0ooO0oOOOOo , "setting.jpg" ) , isFolder = False )
 if 97 - 97: Ii1I + o0oOOo0O0Ooo . OOooOOo + I1ii11iIi11i % iII111i
 if 95 - 95: i1IIi
 if 3 - 3: I1Ii111 - O0 / I1Ii111 % OoO0O00 / I1Ii111 . I1IiiI
def iiI111I1iIiI ( ) :
 II = Ii1I1IIii1II ( O00oooo0O ( 30004 ) ) . strip ( )
 if len ( II ) < 1 :
  return
 O0ii1ii1ii = oooooOoo0ooo ( 30002 , 30005 , 30006 , 30016 , 30017 , fileType = 1 , fileMask = '.plx|.m3u|.m3u8' )
 if len ( O0ii1ii1ii ) < 1 :
  return
 I1IIIii = oooooOoo0ooo ( 30022 , 30022 , 30022 , 30024 , 30025 , 30021 , fileType = 2 )
 I1I1IiI1 = '' if O0ii1ii1ii . endswith ( '.plx' ) else oooooOoo0ooo ( 30018 , 30019 , 30020 , 30019 , 30020 , 30021 , fileType = 0 )
 if I1I1IiI1 . startswith ( 'http' ) and not I1I1IiI1 . endswith ( '/' ) :
  I1I1IiI1 += '/'
 III1iII1I1ii = oOOo0 ( O00oooo0O ( 30034 ) , '0' ) if O0ii1ii1ii . startswith ( 'http' ) else 0
 if III1iII1I1ii is None :
  III1iII1I1ii = 0
 IiI11iII1 = common . ReadList ( I1Ii )
 for I1i1iii in IiI11iII1 :
  if I1i1iii [ "url" ] . lower ( ) == O0ii1ii1ii . lower ( ) :
   xbmc . executebuiltin ( 'Notification({0}, "{1}" {2}, 5000, {3})' . format ( Ii1IIii11 , I1i1iii [ "name" ] , O00oooo0O ( 30007 ) , Oooo0000 ) )
   return
 IiI11iII1 . append ( { "name" : II , "url" : O0ii1ii1ii , "image" : I1IIIii , "logos" : I1I1IiI1 , "cache" : III1iII1I1ii , "uuid" : str ( random . uuid4 ( ) ) } )
 if common . SaveList ( I1Ii , IiI11iII1 ) :
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 54 - 54: O0 - IiII % OOooOOo
  if 77 - 77: OoOoOO00 / I1IiiI / OoO0O00 + OoO0O00 . OOooOOo
def oooooOoo0ooo ( choiceTitle , fileTitle , urlTitle , choiceFile , choiceUrl , choiceNone = None , fileType = 1 , fileMask = None , defaultText = "" ) :
 ii1ii11IIIiiI = ''
 O00OOOoOoo0O = [ O00oooo0O ( choiceFile ) , O00oooo0O ( choiceUrl ) ]
 if choiceNone is not None :
  O00OOOoOoo0O = [ O00oooo0O ( choiceNone ) ] + O00OOOoOoo0O
 O000OOo00oo = oo0OOo ( O00oooo0O ( choiceTitle ) , O00OOOoOoo0O )
 if choiceNone is None and O000OOo00oo == 0 or choiceNone is not None and O000OOo00oo == 1 :
  if not defaultText . startswith ( 'http' ) :
   defaultText = ""
  ii1ii11IIIiiI = Ii1I1IIii1II ( O00oooo0O ( fileTitle ) , defaultText ) . strip ( )
 elif choiceNone is None and O000OOo00oo == 1 or choiceNone is not None and O000OOo00oo == 2 :
  if defaultText . startswith ( 'http' ) :
   defaultText = ""
  ii1ii11IIIiiI = xbmcgui . Dialog ( ) . browse ( fileType , O00oooo0O ( urlTitle ) , 'files' , fileMask , False , False , defaultText )
 return ii1ii11IIIiiI
 if 64 - 64: I11i
 if 22 - 22: Oo0Ooo + Ii1I % I1ii11iIi11i
def iI1 ( iuuid , listFile ) :
 if 28 - 28: OoO0O00 + Ii1I / OoO0O00 . II111iiii
 IiI11iII1 = common . ReadList ( listFile )
 ooOOoooooo = common . ReadList ( o0oOo0Ooo0O )
 if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
 Ii1IOo0o0 = 0
 for III1Iiii1I11 in IiI11iII1 :
  if III1Iiii1I11 [ "uuid" ] == iuuid :
   del IiI11iII1 [ Ii1IOo0o0 ]
  Ii1IOo0o0 += 1
  if 9 - 9: I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / iIii1I11I1II1 - o0oOOo0O0Ooo
  if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
 for O0Oo000ooO00 in ooOOoooooo :
  Ii1IOo0o0 = 0
  for oOoOooOo0o0 in O0Oo000ooO00 [ "data" ] :
   if iuuid in oOoOooOo0o0 :
    del O0Oo000ooO00 [ "data" ] [ Ii1IOo0o0 ]
   Ii1IOo0o0 += 1
   if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
 common . SaveList ( listFile , IiI11iII1 )
 common . SaveList ( o0oOo0Ooo0O , ooOOoooooo )
 if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 51 - 51: O0 + iII111i
 if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
def ii ( index ) :
 if 90 - 90: o0oOOo0O0Ooo % i1IIi / OoO0O00
 IIi = common . ReadList ( IIIiiiiiIii )
 if index < 0 or index >= len ( IIi ) :
  return
 del IIi [ index ]
 common . SaveList ( IIIiiiiiIii , IIi )
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 41 - 41: Ii1I - O0 - O0
 if 68 - 68: OOooOOo % I1Ii111
def ooO00OO0 ( url , cache ) :
 i11111IIIII = [ ]
 IiI11iII1 = common . plx2list ( url , cache )
 iIiii1i111iI1 = IiI11iII1 [ 0 ] [ "background" ]
 for i11oO0oOo0 in IiI11iII1 [ 1 : ] :
  I1I1I = "" if "thumb" not in i11oO0oOo0 else common . GetEncodeString ( i11oO0oOo0 [ "thumb" ] )
  iiii = common . GetEncodeString ( i11oO0oOo0 [ "name" ] )
  if i11oO0oOo0 [ "type" ] == 'playlist' :
   I1IIiiIiii ( "{0}" . format ( iiii ) , i11oO0oOo0 [ "url" ] , 1 , I1I1I , background = iIiii1i111iI1 )
  else :
   I1IIiiIiii ( iiii , i11oO0oOo0 [ "url" ] , 3 , I1I1I , isFolder = False , IsPlayable = True , background = iIiii1i111iI1 )
   i11111IIIII . append ( { "url" : i11oO0oOo0 [ "url" ] , "image" : I1I1I , "name" : iiii } )
   if 95 - 95: II111iiii + o0oOOo0O0Ooo + iII111i * iIii1I11I1II1 % oO0o / IiII
 common . SaveList ( OO00O0O0O00Oo , i11111IIIII )
 if 56 - 56: iII111i
 if 86 - 86: II111iiii % I1Ii111
def iiIIiiIi1Ii11 ( url , logos , cache , gListIndex = - 1 ) :
 if 65 - 65: II111iiii . OOooOOo % I11i . i11iIiiIii + O0
 I1IiiiiI = None
 if 80 - 80: I1Ii111 . i11iIiiIii - o0oOOo0O0Ooo
 i11111IIIII = [ ]
 IiI11iII1 = common . m3u2list ( url , cache )
 iIiIIi1 = [ ]
 if 7 - 7: ooOoO0o - Oo0Ooo - oO0o + ooOoO0o
 for i11oO0oOo0 in IiI11iII1 :
  if IiIiIi :
   iI1I11iiI1i = [ iIiIIi1 . index ( oO0o0Ooooo ) for oO0o0Ooooo in iIiIIi1 if len ( oO0o0Ooooo ) > 0 and oO0o0Ooooo [ 0 ] . get ( "group_title" , oO0o0Ooooo [ 0 ] [ "display_name" ] ) == i11oO0oOo0 . get ( "group_title" , i11oO0oOo0 [ "display_name" ] ) ]
   if 94 - 94: o0oOOo0O0Ooo * Ii1I / Oo0Ooo / Ii1I
  if IiIiIi and len ( iI1I11iiI1i ) == 1 :
   iIiIIi1 [ iI1I11iiI1i [ 0 ] ] . append ( i11oO0oOo0 )
  else :
   iIiIIi1 . append ( [ i11oO0oOo0 ] )
   if 87 - 87: Oo0Ooo . IiII
 for O0OO0O in iIiIIi1 :
  OO = iIiIIi1 . index ( O0OO0O )
  if gListIndex > - 1 and gListIndex != OO :
   continue
  OoOoO = gListIndex < 0 and len ( O0OO0O ) > 1
  Ii1I1i = [ O0OO0O [ 0 ] ] if OoOoO else O0OO0O
  if 99 - 99: oO0o . iII111i + ooOoO0o % oO0o . i11iIiiIii % O0
  for i11oO0oOo0 in Ii1I1i :
   iiii = common . GetEncodeString ( i11oO0oOo0 [ "display_name" ] ) if not OoOoO else common . GetEncodeString ( i11oO0oOo0 . get ( "group_title" , i11oO0oOo0 [ "display_name" ] ) )
   oOO00O = "" if I1IiiiiI is None else I1IiiiiI [ i11oO0oOo0 [ "group_title" ] ] [ "overview" ] if i11oO0oOo0 [ "group_title" ] in I1IiiiiI else ""
   I11 = "" if I1IiiiiI is None else I1IiiiiI [ i11oO0oOo0 [ "group_title" ] ] [ "fanarts" ] [ 0 ] if ( i11oO0oOo0 [ "group_title" ] in I1IiiiiI and len ( I1IiiiiI [ i11oO0oOo0 [ "group_title" ] ] [ "fanarts" ] ) > 0 ) else ""
   if 77 - 77: Oo0Ooo - i1IIi - I11i . OoOoOO00
   if OoOoO :
    iiii = '{0}' . format ( iiii )
    IiI1i = url
    try :
     I1IIIii = i11oO0oOo0 [ 'tvg_logo' ] if I1IiiiiI is None else I1IiiiiI [ i11oO0oOo0 [ "group_title" ] ] [ "poster" ] if i11oO0oOo0 [ "group_title" ] in I1IiiiiI else i11oO0oOo0 [ 'tvg_logo' ]
    except KeyError :
     I1IIIii = "DefaultTVShows.gif"
    I1IIiiIiii ( iiii , url , 10 , index = OO , iconimage = I1IIIii , plot = oOO00O , fanart = I11 )
   else :
    IiI1i = common . GetEncodeString ( i11oO0oOo0 [ "url" ] )
    I1IIIii = i11oO0oOo0 . get ( "tvg_logo" , i11oO0oOo0 . get ( "logo" , "" ) )
    if logos is not None and logos != '' and I1IIIii != "" and not I1IIIii . startswith ( 'http' ) :
     I1IIIii = logos + I1IIIii
    I1IIiiIiii ( iiii , IiI1i , 3 , I1IIIii , index = - 1 , isFolder = False , IsPlayable = True , plot = oOO00O , fanart = I11 )
   i11111IIIII . append ( { "url" : IiI1i , "image" : I1IIIii , "name" : iiii } )
   if 92 - 92: IiII . IiII + OoO0O00
 common . SaveList ( OO00O0O0O00Oo , i11111IIIII )
 if 9 - 9: I1IiiI * O0 + IiII - I11i * I1Ii111
 if 64 - 64: iIii1I11I1II1 - iIii1I11I1II1 / i11iIiiIii % Oo0Ooo - iII111i
def Oo0 ( name , url , iconimage = None ) :
 url = common . getFinalUrl ( url )
 xbmc . log ( '--- Playing "{0}". {1}' . format ( name , url ) , 2 )
 O0o0OO0O00O = xbmcgui . ListItem ( path = url )
 O0o0OO0O00O . setInfo ( type = "Video" , infoLabels = { "mediatype" : "movie" , "Title" : name } )
 if 19 - 19: I1Ii111 + iIii1I11I1II1 . OoooooooOO . I11i / I1Ii111 + IiII
 if iconimage is not None :
  try :
   O0o0OO0O00O . setArt ( { 'thumb' : iconimage } )
  except :
   O0o0OO0O00O . setThumbnailImage ( iconimage )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0o0OO0O00O )
 if 85 - 85: I1ii11iIi11i - iIii1I11I1II1
 if 31 - 31: OoooooooOO - OoooooooOO * I11i - oO0o
def I1IIiiIiii ( name , url , mode , iconimage = '' , logos = '' , index = - 1 , move = 0 , uuid = '0' , isFolder = True , IsPlayable = False ,
 background = None , cacheMin = '0' , plot = "" , fanart = "" , addToVdir = True ) :
 OooOOO0OOOO = { 'name' : name , 'url' : url , 'mode' : mode , 'iconimage' : iconimage , 'logos' : logos , 'cache' : cacheMin , 'uuid' : uuid }
 if 29 - 29: iII111i + II111iiii % O0 . OoOoOO00 + oO0o / I1IiiI
 O0oOOoOooooO = xbmcgui . ListItem ( name , iconimage , iconimage )
 O0oOOoOooooO . setArt ( { 'icon' : iconimage , 'thumb' : iconimage } )
 O0oOOoOooooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "plot" : plot , "plotoutline" : plot , "tagline" : plot } )
 O0oOOoOooooO . setProperty ( "fanart_image" , fanart )
 oooOo0OOOoo0 = [ ]
 if 51 - 51: Oo0Ooo / OoOoOO00 . OOooOOo * o0oOOo0O0Ooo + OoO0O00 * IiII
 OOOoOo = 21
 if IsPlayable :
  O0oOOoOooooO . setProperty ( 'IsPlayable' , 'true' )
 if background != None :
  O0oOOoOooooO . setProperty ( 'fanart_image' , background )
  if 51 - 51: ooOoO0o / iIii1I11I1II1 % Oo0Ooo * I1IiiI % I1Ii111
 if mode == 1 or mode == 2 :
  oooOo0OOOoo0 = [
 ( O00oooo0O ( 30008 ) , 'RunPlugin({0}?index={1}&mode=22&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) ,
 ( O00oooo0O ( 30026 ) , 'RunPlugin({0}?index={1}&mode=23&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) ,
 ( O00oooo0O ( 30027 ) , 'RunPlugin({0}?index={1}&mode=24&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) ,
 ( O00oooo0O ( 30028 ) , 'RunPlugin({0}?index={1}&mode=25&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) )
 ]
  if 76 - 76: o0oOOo0O0Ooo - i11iIiiIii
  if mode == 2 and not url . endswith ( '.plx' ) :
   oooOo0OOOoo0 . append ( ( O00oooo0O ( 30029 ) , 'RunPlugin({0}?index={1}&mode=26&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) )
  if url . startswith ( 'http' ) :
   oooOo0OOOoo0 . append ( ( O00oooo0O ( 30035 ) , 'RunPlugin({0}?index={1}&mode=28&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) )
   if 14 - 14: OoOoOO00 + oO0o
 elif mode == 3 :
  oooOo0OOOoo0 = [
 ( O00oooo0O ( 30009 ) , 'RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3}&uuid={4})' . format ( sys . argv [ 0 ] , urllib . parse . quote_plus ( url ) , iconimage , name , uuid ) )
 ]
  if 52 - 52: OoooooooOO - ooOoO0o
 elif mode == 32 :
  oooOo0OOOoo0 = [
 ( O00oooo0O ( 30010 ) , 'RunPlugin({0}?index={1}&mode=33)' . format ( sys . argv [ 0 ] , index ) ) ,
 ( O00oooo0O ( 30026 ) , 'RunPlugin({0}?index={1}&mode=35)' . format ( sys . argv [ 0 ] , index ) ) ,
 ( O00oooo0O ( 30027 ) , 'RunPlugin({0}?index={1}&mode=36)' . format ( sys . argv [ 0 ] , index ) ) ,
 ( O00oooo0O ( 30028 ) , 'RunPlugin({0}?index={1}&mode=37)' . format ( sys . argv [ 0 ] , index ) )
 ]
  OOOoOo = 38
  if 74 - 74: iII111i + o0oOOo0O0Ooo
 elif mode == 44 :
  oooOo0OOOoo0 = [
 ( O00oooo0O ( 30043 ) , 'RunPlugin({0}?index={1}&mode=46&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) ,
 ( O00oooo0O ( 30044 ) , 'RunPlugin({0}?index={1}&mode=47&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) )
 ]
  if 71 - 71: Oo0Ooo % OOooOOo
 if mode == 1 or mode == 2 or mode == 32 :
  oooOo0OOOoo0 += [
 ( O00oooo0O ( 30030 ) , 'RunPlugin({0}?index={1}&mode={2}&move=-1&uuid={3})' . format ( sys . argv [ 0 ] , index , OOOoOo , uuid ) ) ,
 ( O00oooo0O ( 30031 ) , 'RunPlugin({0}?index={1}&mode={2}&move=1&uuid={3})' . format ( sys . argv [ 0 ] , index , OOOoOo , uuid ) )

  ]
  if 98 - 98: I11i % i11iIiiIii % ooOoO0o + Ii1I
  if addToVdir :
   oooOo0OOOoo0 += [
 ( O00oooo0O ( 30041 ) , 'RunPlugin({0}?index={1}&mode=45&move=-1&uuid={2})' . format ( sys . argv [ 0 ] , index , uuid ) ) ,
 ]
   if 78 - 78: I1ii11iIi11i % oO0o / iII111i - iIii1I11I1II1
 if mode == 10 :
  OooOOO0OOOO [ 'index' ] = index
  if 69 - 69: I1Ii111
 O0oOOoOooooO . addContextMenuItems ( oooOo0OOOoo0 )
 if 11 - 11: I1IiiI
 I1111i = '{0}?{1}' . format ( sys . argv [ 0 ] , urllib . parse . urlencode ( OooOOO0OOOO ) )
 xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111i , listitem = O0oOOoOooooO , isFolder = isFolder )
 if 14 - 14: OOooOOo / o0oOOo0O0Ooo
 if 32 - 32: I1IiiI * Oo0Ooo
def Ii1I1IIii1II ( title = "" , defaultText = "" ) :
 O0OooOo0o = xbmc . Keyboard ( defaultText , title )
 O0OooOo0o . doModal ( )
 iiI11ii1I1 = "" if not O0OooOo0o . isConfirmed ( ) else O0OooOo0o . getText ( )
 return iiI11ii1I1
 if 82 - 82: II111iiii % I11i / OoO0O00 + OoOoOO00 / o0oOOo0O0Ooo / I1Ii111
 if 70 - 70: oO0o
def oo0OOo ( title , chList ) :
 oOOoO0o0oO = xbmcgui . Dialog ( )
 o0Oo0oO0oOO00 = oOOoO0o0oO . select ( title , chList )
 return o0Oo0oO0oOO00
 if 92 - 92: OoooooooOO * I1Ii111
 if 100 - 100: I1Ii111 + I1Ii111 * IiII
def I1i ( url , iconimage , name ) :
 if 99 - 99: I1Ii111 + OoOoOO00 * iIii1I11I1II1 / OoooooooOO
 IIi = common . ReadList ( IIIiiiiiIii )
 for I1i1iii in IIi :
  if I1i1iii [ "url" ] . lower ( ) == url . lower ( ) :
   xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( Ii1IIii11 , name , O00oooo0O ( 30011 ) , Oooo0000 ) )
   return
   if 46 - 46: I11i / Ii1I
 IiI11iII1 = common . ReadList ( OO00O0O0O00Oo )
 for i11oO0oOo0 in IiI11iII1 :
  if i11oO0oOo0 [ "name" ] . lower ( ) == name . lower ( ) :
   url = i11oO0oOo0 [ "url" ]
   iconimage = i11oO0oOo0 [ "image" ]
   break
 if not iconimage :
  iconimage = ""
  if 57 - 57: IiII / iII111i * O0 - OoooooooOO % iIii1I11I1II1
 ii11i = { "url" : url , "image" : iconimage , "name" : name }
 IIi . append ( ii11i )
 common . SaveList ( IIIiiiiiIii , IIi )
 xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( Ii1IIii11 , name , O00oooo0O ( 30012 ) , Oooo0000 ) )
 if 73 - 73: OOooOOo
 if 70 - 70: iIii1I11I1II1
def i11ii1iI ( ) :
 i1I = Ii1I1IIii1II ( O00oooo0O ( 30040 ) , "My new directory name" )
 oO0 = xbmcgui . Dialog ( ) . browse ( 1 , O00oooo0O ( 30042 ) , 'files' )
 if 42 - 42: o0oOOo0O0Ooo + i1IIi - Ii1I / IiII
 if i1I != "" :
  o00OO00OoO = common . ReadList ( o0oOo0Ooo0O )
  o00OO00OoO . append ( { "name" : i1I , "data" : [ ] , "icon" : oO0 , "uuid" : str ( random . uuid4 ( ) ) } )
  if 9 - 9: O0 % O0 - o0oOOo0O0Ooo
  common . SaveList ( o0oOo0Ooo0O , o00OO00OoO )
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 51 - 51: I1IiiI . iIii1I11I1II1 - I1ii11iIi11i / O0
  if 52 - 52: o0oOOo0O0Ooo + O0 + iII111i + Oo0Ooo % iII111i
def OOIi1iI111II1I1 ( playlist_uuid ) :
 if 91 - 91: OOooOOo % OOooOOo - I1IiiI
 I1iiii1I = common . ReadList ( o0oOo0Ooo0O )
 if 54 - 54: I1IiiI / I1Ii111 / iIii1I11I1II1 % OoO0O00 % Ii1I
 oOOoO0o0oO = xbmcgui . Dialog ( )
 oooO = oOOoO0o0oO . select ( "Choose the directory were to attach this playlist" , [ I1i1iii [ "name" ] for I1i1iii in I1iiii1I ] )
 I1iiii1I [ oooO ] [ "data" ] . append ( playlist_uuid )
 common . SaveList ( o0oOo0Ooo0O , I1iiii1I )
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 71 - 71: I11i
 if 41 - 41: IiII / O0
def o0oO0oooOoo ( iuuid , with_contents = False ) :
 o00OO00OoO = common . ReadList ( o0oOo0Ooo0O )
 OOOO0OOoO0O0 = 0
 for iIIIi1 in o00OO00OoO :
  if iIIIi1 [ "uuid" ] == iuuid :
   if with_contents :
    I1III1111iIi = common . ReadList ( I1Ii )
    Ii1IOo0o0 = 0
    I1i111I = iIIIi1 [ "data" ]
    I1i111I = [ oOoOooOo0o0 for oOoOooOo0o0 in I1i111I ]
    for Ooo in I1III1111iIi :
     if Ooo [ "uuid" ] in I1i111I :
      del I1III1111iIi [ Ii1IOo0o0 ]
     Ii1IOo0o0 += 1
    common . SaveList ( I1Ii , I1III1111iIi )
   del o00OO00OoO [ OOOO0OOoO0O0 ]
   common . SaveList ( o0oOo0Ooo0O , o00OO00OoO )
   xbmc . executebuiltin ( "Container.Refresh()" )
  OOOO0OOoO0O0 += 1
  if 65 - 65: O0 * OoooooooOO % OOooOOo / IiII - Ii1I / I11i
  if 56 - 56: I1IiiI * i11iIiiIii * I1Ii111
def oOoOo0O0OOOoO ( directory_uuid ) :
 o00OO00OoO = common . ReadList ( o0oOo0Ooo0O )
 iI11IIIiii1II = i1II1i ( directory_uuid )
 if 83 - 83: OoOoOO00 - Ii1I / I11i / I1Ii111 + oO0o - O0
 if iI11IIIiii1II is None :
  return
  if 4 - 4: OOooOOo * OoO0O00 % i1IIi * i11iIiiIii % Oo0Ooo - oO0o
 IiI11iII1 = common . ReadList ( I1Ii )
 OOoOoOo = [ ]
 if 98 - 98: iII111i
 for OooooO0oOOOO in iI11IIIiii1II :
  for III1Iiii1I11 in IiI11iII1 :
   if OooooO0oOOOO == III1Iiii1I11 [ "uuid" ] :
    OOoOoOo . append ( III1Iiii1I11 )
    if 100 - 100: iII111i % OOooOOo
 o0OOOOO00o0O0 ( OOoOoOo , addToVdir = False )
 if 86 - 86: Oo0Ooo . O0 - OoooooooOO . OoO0O00 + Ii1I
 if 57 - 57: o0oOOo0O0Ooo . i1IIi . IiII * i11iIiiIii + I1Ii111 . IiII
def oo0O00Oooo0O0 ( ) :
 I1IIiiIiii ( "[COLOR orange][B]{0}[/B][/COLOR]" . format ( O00oooo0O ( 30013 ) ) , "favorites" , 34 , os . path . join ( oo0ooO0oOOOOo , "bright_yellow_star.jpg" ) , isFolder = False )
 IiI11iII1 = common . ReadList ( IIIiiiiiIii )
 Ii1IOo0o0 = 0
 for i11oO0oOo0 in IiI11iII1 :
  I1IIiiIiii ( i11oO0oOo0 [ "name" ] , i11oO0oOo0 [ "url" ] , 32 , i11oO0oOo0 [ "image" ] , index = Ii1IOo0o0 , isFolder = False , IsPlayable = True )
  Ii1IOo0o0 += 1
  if 34 - 34: ooOoO0o . o0oOOo0O0Ooo % O0 * iII111i + I1IiiI
  if 77 - 77: Ii1I + II111iiii . OoOoOO00 * I1Ii111 + OOooOOo + OOooOOo
def I1ii1I1iiii ( ) :
 iiI = Ii1I1IIii1II ( O00oooo0O ( 30014 ) )
 if len ( iiI ) < 1 :
  return
 IiI1i = Ii1I1IIii1II ( O00oooo0O ( 30015 ) )
 if len ( IiI1i ) < 1 :
  return
 I1IIIii = oooooOoo0ooo ( 30023 , 30023 , 30023 , 30024 , 30025 , 30021 , fileType = 2 )
 if 56 - 56: Oo0Ooo . I1ii11iIi11i . I1IiiI
 IIi = common . ReadList ( IIIiiiiiIii )
 for I1i1iii in IIi :
  if I1i1iii [ "url" ] . lower ( ) == IiI1i . lower ( ) :
   xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( Ii1IIii11 , iiI , O00oooo0O ( 30011 ) , Oooo0000 ) )
   return
   if 39 - 39: O0 + I1Ii111
 ii11i = { "url" : IiI1i , "image" : I1IIIii , "name" : iiI }
 if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoOoOO00 + O0
 IIi . append ( ii11i )
 if common . SaveList ( IIIiiiiiIii , IIi ) :
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 26 - 26: I1ii11iIi11i - OoooooooOO
  if 11 - 11: I1IiiI * oO0o
def o000oo ( iuuid , listFile ) :
 IiI11iII1 = common . ReadList ( listFile )
 if 95 - 95: ooOoO0o / ooOoO0o
 Ii1IOo0o0 = 0
 for III1Iiii1I11 in IiI11iII1 :
  if III1Iiii1I11 [ "uuid" ] == iuuid :
   return Ii1IOo0o0
  Ii1IOo0o0 += 1
  if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
  if 55 - 55: ooOoO0o - I11i + II111iiii + iII111i % Ii1I
def i1II1i ( iuuid ) :
 iiI11i1II = common . ReadList ( o0oOo0Ooo0O )
 for iIIIi1 in iiI11i1II :
  if iIIIi1 [ "uuid" ] == iuuid :
   return iIIIi1 [ "data" ]
 return None
 if 51 - 51: o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * O0 - OOooOOo % Oo0Ooo
 if 65 - 65: ooOoO0o
def o0OooOOOOOO ( iuuid , listFile , key , title , favourites = False ) :
 IiI11iII1 = common . ReadList ( listFile )
 OOooO0o0 = o000oo ( iuuid , listFile ) if not favourites else iuuid
 if 15 - 15: i1IIi + OoOoOO00
 str = Ii1I1IIii1II ( O00oooo0O ( title ) , IiI11iII1 [ OOooO0o0 ] [ key ] )
 if len ( str ) < 1 :
  return
  if 48 - 48: I1IiiI % iII111i / iIii1I11I1II1
 IiI11iII1 [ OOooO0o0 ] [ key ] = str
 if common . SaveList ( listFile , IiI11iII1 ) :
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / I1ii11iIi11i
  if 96 - 96: OoooooooOO + oO0o
def iiII1i11i ( iuuid , listFile , key , choiceTitle , fileTitle , urlTitle , choiceFile , choiceUrl , choiceNone = None , fileType = 1 , fileMask = None , favourites = False ) :
 OOooO0o0 = o000oo ( iuuid , listFile ) if not favourites else iuuid
 IiI11iII1 = common . ReadList ( listFile )
 IiIi = IiI11iII1 [ OOooO0o0 ] . get ( key , "" )
 str = oooooOoo0ooo ( choiceTitle , fileTitle , urlTitle , choiceFile , choiceUrl , choiceNone , fileType , fileMask , IiIi )
 if key == "url" and len ( str ) < 1 :
  return
 elif key == "logos" and str . startswith ( 'http' ) and not str . endswith ( '/' ) :
  str += '/'
 IiI11iII1 [ OOooO0o0 ] [ key ] = str
 if common . SaveList ( listFile , IiI11iII1 ) :
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 87 - 87: I1ii11iIi11i - I1ii11iIi11i - iII111i + oO0o
  if 82 - 82: oO0o / iIii1I11I1II1 . I1IiiI . OOooOOo / o0oOOo0O0Ooo
def iiI1I1 ( index , step ) :
 if 56 - 56: I1IiiI . O0 + Oo0Ooo
 i1II1I1Iii1 = common . ReadList ( IIIiiiiiIii )
 if 30 - 30: OoooooooOO - OoOoOO00
 if index + step >= len ( i1II1I1Iii1 ) or index + step < 0 :
  return
 if step == 0 :
  step = Ooo00O0o ( len ( i1II1I1Iii1 ) , index )
  if 72 - 72: iIii1I11I1II1 * Ii1I % ooOoO0o / OoO0O00
 if step < 0 :
  I11i1II = i1II1I1Iii1 [ 0 : index + step ] + [ i1II1I1Iii1 [ index ] ] + i1II1I1Iii1 [ index + step : index ] + i1II1I1Iii1 [ index + 1 : ]
 elif step > 0 :
  I11i1II = i1II1I1Iii1 [ 0 : index ] + i1II1I1Iii1 [ index + 1 : index + 1 + step ] + [ i1II1I1Iii1 [ index ] ] + i1II1I1Iii1 [ index + 1 + step : ]
 else :
  return
 common . SaveList ( IIIiiiiiIii , I11i1II )
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 72 - 72: iIii1I11I1II1 . i1IIi / Oo0Ooo . II111iiii
 if 54 - 54: II111iiii % II111iiii
def Oo00000o0o ( iuuid , step , listFile ) :
 if 72 - 72: OOooOOo % I1ii11iIi11i + OoO0O00 / oO0o + IiII
 def I1I1i ( index , step , tList ) :
  I11i1II = None
  if index + step >= len ( tList ) or index + step < 0 :
   return None
   if 1 - 1: I11i % OOooOOo + O0 + i1IIi - OoO0O00
  if step == 0 :
   step = Ooo00O0o ( len ( tList ) , index )
   if 22 - 22: I1IiiI % I1ii11iIi11i
  if step < 0 :
   I11i1II = tList [ 0 : index + step ] + [ tList [ index ] ] + tList [ index + step : index ] + tList [ index + 1 : ]
   if 57 - 57: OOooOOo + O0 . Ii1I
  elif step > 0 :
   I11i1II = tList [ 0 : index ] + tList [ index + 1 : index + 1 + step ] + [ tList [ index ] ] + tList [ index + 1 + step : ]
   if 46 - 46: IiII
  else :
   return None
   if 45 - 45: ooOoO0o
  return I11i1II
  if 21 - 21: oO0o . I1Ii111 . OOooOOo / Oo0Ooo / I1Ii111
 i1II1I1Iii1 = common . ReadList ( listFile )
 if 17 - 17: OOooOOo / OOooOOo / I11i
 if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
 dir = False
 I1iiii1I = common . ReadList ( o0oOo0Ooo0O )
 for iIIIi1 in I1iiii1I :
  OooO0oo = [ oOoOooOo0o0 for oOoOooOo0o0 in iIIIi1 [ "data" ] ]
  if iuuid in OooO0oo :
   dir = iIIIi1
   if 89 - 89: Ii1I
 if not dir is False :
  if 76 - 76: ooOoO0o
  iI11IIIiii1II = i1II1i ( dir [ "uuid" ] )
  if 15 - 15: OOooOOo . I11i + OoooooooOO - OoO0O00
  Oo0oooooOOO000Oo = [ Ooo00OoOOO for Ooo00OoOOO in i1II1I1Iii1 if Ooo00OoOOO [ "uuid" ] in iI11IIIiii1II ]
  Oo0OO0000oooo = [ Ooo00OoOOO for Ooo00OoOOO in i1II1I1Iii1 if Ooo00OoOOO [ "uuid" ] not in iI11IIIiii1II ]
  if 7 - 7: oO0o - OoO0O00 - O0 % oO0o - II111iiii
  Oo0oooooOOO000Oo = I1I1i ( iI11IIIiii1II . index ( iuuid ) , step , Oo0oooooOOO000Oo )
  if 31 - 31: iII111i / Oo0Ooo - iII111i - OOooOOo
  if not Oo0oooooOOO000Oo is None :
   common . SaveList ( listFile , Oo0OO0000oooo + Oo0oooooOOO000Oo )
   if 7 - 7: iII111i % O0 . OoOoOO00 + I1IiiI - I11i
   if 75 - 75: I11i
  OO = I1iiii1I . index ( iIIIi1 )
  iIIIi1 [ "data" ] = [ I1i1iii [ "uuid" ] for I1i1iii in Oo0oooooOOO000Oo ]
  I1iiii1I [ OO ] = iIIIi1
  common . SaveList ( o0oOo0Ooo0O , I1iiii1I )
  if 71 - 71: ooOoO0o
 else :
  iI11IIIiii1II = [ I1i1iii for ii11i in I1iiii1I for I1i1iii in i1II1i ( ii11i [ "uuid" ] ) ]
  Ooo0o00o0o = [ III1Iiii1I11 for III1Iiii1I11 in common . ReadList ( listFile ) if III1Iiii1I11 [ "uuid" ] in iI11IIIiii1II ]
  IiIIIIIi = [ III1Iiii1I11 for III1Iiii1I11 in common . ReadList ( listFile ) if not III1Iiii1I11 [ "uuid" ] in iI11IIIiii1II ]
  if 11 - 11: i1IIi % i11iIiiIii - i1IIi * OoOoOO00
  OO = 0
  for III1Iiii1I11 in IiIIIIIi :
   if III1Iiii1I11 [ "uuid" ] == iuuid :
    break
   OO += 1
   if 39 - 39: I1Ii111
  Oo0oooooOOO000Oo = I1I1i ( OO , step , IiIIIIIi )
  if 86 - 86: I11i * I1IiiI + I11i + II111iiii
  if not Oo0oooooOOO000Oo is None :
   common . SaveList ( listFile , Ooo0o00o0o + Oo0oooooOOO000Oo )
   if 8 - 8: I1Ii111 - iII111i / ooOoO0o
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 96 - 96: OoOoOO00
 if 29 - 29: I1ii11iIi11i / i1IIi . I1IiiI - OoOoOO00 - OoOoOO00 - Ii1I
 if 20 - 20: i1IIi % OoO0O00 . I1IiiI / IiII * i11iIiiIii * OOooOOo
def OOoi1i11I1I1iii1 ( msg ) :
 try :
  if platform . system ( ) == 'Linux' :
   I1iii11 = 'Android 9; Mobile; rv:68.0'
  elif platform . system ( ) == 'Windows' :
   I1iii11 = 'Windows NT 6.1; WOW64; rv:54.0'
  elif platform . system ( ) == 'IOS' :
   I1iii11 = 'iPhone; CPU iPhone OS 12_2 like Mac OS X'
  else :
   I1iii11 = ''
  ooo0O = {
 "Accept-Language" : "en-US,en;q=0.5" ,
 "\x55\x73\x65\x72\x2d\x61\x67\x65\x6e\x74" : I1iii11 ,
 "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,/;q=0.8" ,
 "Connection" : "keep-alive"
 }
  iII1iii = urllib2 . build_opener ( )
  iII1iii . addheaders = [ ( 'Accept-Language' , 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7' ) , ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36' ) , ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' ) , ( 'Referer' , i11i1iiiII ) ]
  ii11i = iII1iii . open ( ooOO0oO0oo00o ) . read ( )
 except :
  pass
  if 83 - 83: oO0o - II111iiii - iII111i
OOoi1i11I1I1iii1 ( True )
ooOO0oO0oo00o = 'https://whos.amung.us/pingjs/?k=/ehry9bo77t'
i11i1iiiII = 'New-Espada Negra-1.0.0+Matrix'
if 3 - 3: I1Ii111
if 45 - 45: I1Ii111
def oO ( url ) :
 try :
  import urllib . request as urllib2
 except ImportError :
  import urllib2
 iII1iii = urllib2 . build_opener ( )
 iII1iii . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0)/Espada-Negra Gecko/20100101 Firefox/19.0' ) ]
 if 17 - 17: Oo0Ooo % OOooOOo . i1IIi / OoooooooOO
 IIiIiiii = iII1iii . open ( url )
 ii11i = IIiIiiii . read ( ) . decode ( 'utf-8' )
 O0000OOO0 = ii11i
 return O0000OOO0
 if 51 - 51: I1IiiI / IiII / Ii1I
 if 6 - 6: Ii1I - ooOoO0o * OOooOOo . iII111i / O0 * ooOoO0o
 if 22 - 22: Oo0Ooo % iII111i * I1ii11iIi11i / OOooOOo % i11iIiiIii * I11i
 if 95 - 95: OoooooooOO - IiII * I1IiiI + OoOoOO00
 if 10 - 10: o0oOOo0O0Ooo / i11iIiiIii
 if 92 - 92: I11i . I1Ii111
 if 85 - 85: I1ii11iIi11i . I1Ii111
 if 78 - 78: ooOoO0o * I1Ii111 + iIii1I11I1II1 + iIii1I11I1II1 / I1Ii111 . Ii1I
def O000 ( msg ) :
 ooo0o000O = OOo . getSetting ( 'mensagem2' )
 if ooo0o000O == 'true' :
  xbmc . executebuiltin ( "Notification({0}, {1}, 10000, {2})" . format ( Ii1IIii11 , "[B][COLOR orange]|[/COLOR][/B] [B]TV AO VIVO[/B] [B][COLOR orange]|[/COLOR][/B] [B]FILMES [B][COLOR orange]|[/COLOR][/B] [B]SERIES[/B] [B][COLOR orange]|[/COLOR][/B] [B]DESENHOS[/B] [B][COLOR orange]|[/COLOR][/B] [B]ANIMES[/B] [B][COLOR orange]|[/COLOR][/B] [B]MELHORES LANÇAMENTOS DUAL AUDIO[/B] [B][COLOR orange]|[/COLOR][/B]" , Oo0o0000o0o0 ) )
  if 100 - 100: oO0o . ooOoO0o * I1ii11iIi11i / iIii1I11I1II1 * i1IIi % ooOoO0o
  if 17 - 17: I11i . IiII - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
  if 39 - 39: IiII * Oo0Ooo + iIii1I11I1II1 - IiII + OOooOOo
  if 69 - 69: O0
  if 85 - 85: ooOoO0o / O0
  if 18 - 18: o0oOOo0O0Ooo % O0 * I1ii11iIi11i
  if 62 - 62: I1Ii111 . IiII . OoooooooOO
  if 11 - 11: OOooOOo / I11i
  if 73 - 73: i1IIi / i11iIiiIii
  if 58 - 58: Oo0Ooo . II111iiii + oO0o - i11iIiiIii / II111iiii / O0
def oOOo0 ( title , defaultt = '' ) :
 oOOoO0o0oO = xbmcgui . Dialog ( )
 ii1ii11IIIiiI = oOOoO0o0oO . input ( title , defaultt = defaultt , type = xbmcgui . INPUT_NUMERIC )
 return None if ii1ii11IIIiiI == '' else int ( ii1ii11IIIiiI )
 if 85 - 85: OoOoOO00 + OOooOOo
 if 10 - 10: IiII / OoO0O00 + OoOoOO00 / i1IIi
def Ooo00O0o ( listLen , index ) :
 oOOoO0o0oO = xbmcgui . Dialog ( )
 i1iII1II11I = oOOo0 ( '{0} (1-{1})' . format ( O00oooo0O ( 30033 ) , listLen ) )
 return 0 if i1iII1II11I is None or i1iII1II11I > listLen or i1iII1II11I <= 0 else i1iII1II11I - 1 - index
 if 54 - 54: IiII + O0 + I11i * I1Ii111 - OOooOOo % oO0o
 if 13 - 13: ooOoO0o / iII111i * OoO0O00 . OoO0O00 * ooOoO0o
def O00oO ( iuuid , listFile ) :
 OOooO0o0 = o000oo ( iuuid , listFile )
 IiI11iII1 = common . ReadList ( listFile )
 IiIi = IiI11iII1 [ OOooO0o0 ] . get ( 'cache' , 0 )
 III1iII1I1ii = oOOo0 ( O00oooo0O ( 30034 ) , str ( IiIi ) ) if IiI11iII1 [ OOooO0o0 ] . get ( 'url' , '0' ) . startswith ( 'http' ) else 0
 if III1iII1I1ii is None :
  return
 IiI11iII1 [ OOooO0o0 ] [ 'cache' ] = III1iII1I1ii
 if common . SaveList ( listFile , IiI11iII1 ) :
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 40 - 40: OoOoOO00 / IiII
  if 79 - 79: OoO0O00 - iIii1I11I1II1 + Ii1I - I1Ii111
def OoO ( ) :
 iIIiii = "false" if IiIiIi else "true"
 OOo . setSetting ( "makeGroups" , iIIiii )
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 61 - 61: IiII . i1IIi / I1Ii111 % i11iIiiIii * iII111i
i1i1i1I = dict ( urllib . parse . parse_qsl ( sys . argv [ 2 ] . replace ( '?' , '' ) ) )
oOoo000 = i1i1i1I . get ( 'url' )
O000OO0 = i1i1i1I . get ( 'logos' , '' )
iiii = i1i1i1I . get ( 'name' )
I1I1I = i1i1i1I . get ( 'iconimage' )
OooOo00o = int ( i1i1i1I . get ( 'cache' , '0' ) )
OOooO0o0 = int ( i1i1i1I . get ( 'index' , '-1' ) )
IiI11i1IIiiI = int ( i1i1i1I . get ( 'move' , '0' ) )
i1iiI11I = int ( i1i1i1I . get ( 'mode' , '0' ) )
uuid = i1i1i1I . get ( 'uuid' , '0' )
if 60 - 60: I1ii11iIi11i * I1IiiI
if i1iiI11I == 0 :
 OOoi1i11I1I1iii1 ( True )
 if 17 - 17: OOooOOo % Oo0Ooo / I1ii11iIi11i . IiII * OOooOOo - II111iiii
 O000 ( True )
 IiII1I11i1I1I ( )
 if 41 - 41: Ii1I
elif i1iiI11I == 1 :
 ooO00OO0 ( oOoo000 , OooOo00o )
 if 77 - 77: I1Ii111
elif i1iiI11I == 2 or i1iiI11I == 10 :
 iiIIiiIi1Ii11 ( oOoo000 , O000OO0 , OooOo00o , OOooO0o0 )
 if 65 - 65: II111iiii . I1IiiI % oO0o * OoO0O00
elif i1iiI11I == 3 or i1iiI11I == 32 :
 Oo0 ( iiii , oOoo000 , I1I1I )
 if 38 - 38: OoOoOO00 / iII111i % Oo0Ooo
elif i1iiI11I == 20 :
 iiI111I1iIiI ( )
 if 11 - 11: iII111i - oO0o + II111iiii - iIii1I11I1II1
elif i1iiI11I == 21 :
 Oo00000o0o ( uuid , IiI11i1IIiiI , I1Ii )
 if 7 - 7: IiII - I11i / II111iiii * Ii1I . iII111i * iII111i
 if 61 - 61: I11i % ooOoO0o - OoO0O00 / Oo0Ooo
 if 4 - 4: OoooooooOO - i1IIi % Ii1I - OOooOOo * o0oOOo0O0Ooo
 if 85 - 85: OoooooooOO * iIii1I11I1II1 . iII111i / OoooooooOO % I1IiiI % O0
elif i1iiI11I == 23 :
 o0OooOOOOOO ( uuid , I1Ii , "name" , 30004 )
 if 36 - 36: Ii1I / II111iiii / IiII / IiII + I1ii11iIi11i
 if 95 - 95: IiII
 if 51 - 51: II111iiii + IiII . i1IIi . I1ii11iIi11i + OoOoOO00 * I1IiiI
 if 72 - 72: oO0o + oO0o / II111iiii . OoooooooOO % Ii1I
elif i1iiI11I == 25 :
 iiII1i11i ( uuid , I1Ii , "image" , 30022 , 30022 , 30022 , 30024 , 30025 , 30021 , 2 )
 if 49 - 49: oO0o . OoO0O00 - Oo0Ooo * OoooooooOO . Oo0Ooo
elif i1iiI11I == 26 :
 iiII1i11i ( uuid , I1Ii , "logos" , 30018 , 30019 , 30020 , 30019 , 30020 , 30021 , 0 )
 if 2 - 2: OoooooooOO % OOooOOo
elif i1iiI11I == 27 :
 common . DelFile ( I1Ii )
 sys . exit ( )
 if 63 - 63: I1IiiI % iIii1I11I1II1
elif i1iiI11I == 28 :
 O00oO ( uuid , I1Ii )
 if 39 - 39: iII111i / II111iiii / I1ii11iIi11i % I1IiiI
elif i1iiI11I == 30 :
 oo0O00Oooo0O0 ( )
 if 89 - 89: I1Ii111 + OoooooooOO + I1Ii111 * i1IIi + iIii1I11I1II1 % I11i
elif i1iiI11I == 31 :
 I1i ( oOoo000 , I1I1I , iiii )
 if 59 - 59: OOooOOo + i11iIiiIii
elif i1iiI11I == 33 :
 ii ( OOooO0o0 )
 if 88 - 88: i11iIiiIii - ooOoO0o
elif i1iiI11I == 34 :
 I1ii1I1iiii ( )
 if 67 - 67: OOooOOo . Oo0Ooo + OoOoOO00 - OoooooooOO
elif i1iiI11I == 35 :
 o0OooOOOOOO ( OOooO0o0 , IIIiiiiiIii , "name" , 30014 , favourites = True )
 if 70 - 70: OOooOOo / II111iiii - iIii1I11I1II1 - iII111i
elif i1iiI11I == 36 :
 o0OooOOOOOO ( OOooO0o0 , IIIiiiiiIii , "url" , 30015 , favourites = True )
 if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - I11i
elif i1iiI11I == 37 :
 iiII1i11i ( OOooO0o0 , IIIiiiiiIii , "image" , 30023 , 30023 , 30023 , 30024 , 30025 , 30021 , 2 , favourites = True )
 if 30 - 30: OoOoOO00
elif i1iiI11I == 38 :
 iiI1I1 ( OOooO0o0 , IiI11i1IIiiI )
 if 21 - 21: i11iIiiIii / I1Ii111 % OOooOOo * O0 . I11i - iIii1I11I1II1
elif i1iiI11I == 39 :
 common . DelFile ( IIIiiiiiIii )
 sys . exit ( )
 if 26 - 26: II111iiii * OoOoOO00
elif i1iiI11I == 43 :
 i11ii1iI ( )
 if 10 - 10: II111iiii . iII111i
elif i1iiI11I == 44 :
 oOoOo0O0OOOoO ( uuid )
 if 32 - 32: Ii1I . IiII . OoooooooOO - OoO0O00 + oO0o
elif i1iiI11I == 45 :
 OOIi1iI111II1I1 ( uuid )
 if 88 - 88: iII111i
elif i1iiI11I == 46 :
 o0oO0oooOoo ( uuid , with_contents = True )
 if 19 - 19: II111iiii * IiII + Ii1I
elif i1iiI11I == 47 :
 o0oO0oooOoo ( uuid )
 if 65 - 65: OOooOOo . I1Ii111 . OoO0O00 . iII111i - OOooOOo
elif i1iiI11I == 48 :
 Doar ( True )
 if 19 - 19: i11iIiiIii + iII111i % ooOoO0o
elif i1iiI11I == 49 : init_SUPORTE ( True )
if 14 - 14: OoO0O00 . II111iiii . I11i / Ii1I % I1ii11iIi11i - ooOoO0o
elif i1iiI11I == 50 :
 OoO ( )
 if 67 - 67: I11i - OOooOOo . i1IIi
elif i1iiI11I == 51 : CheckUpdate ( True )
if 35 - 35: iII111i + ooOoO0o - oO0o . iII111i . IiII
elif i1iiI11I == 52 :
 INFO_SKindex ( True )
 if 87 - 87: OoOoOO00
OOoi1i11I1I1iii1 ( True )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
