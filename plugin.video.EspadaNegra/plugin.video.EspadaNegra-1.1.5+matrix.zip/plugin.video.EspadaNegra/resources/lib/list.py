[
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Brasil 1",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegrabrasil1.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "3ad99ef9-eb57-4e87-ab18-dbbb9b9ffa7b"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Brasil 2",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegrabrasil2.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a56a8001-e0e2-4b7b-89af-42d8b7b539be"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Brasil 3",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegrabrasil3.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "4f03df0c-ab79-4bf3-8860-a4a7a22e1a1b"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Portugal 4",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegraportugal1.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "f553a446-b2a8-4067-a20b-bd45361da911"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Portugal 5",
        "url": "https://flechanegratruck.glitch.me/ADDONTRUCK/tv/epadanegraportugal2.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },    
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Creditos Pluto TV",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-plutotv.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Mundial TV",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-mundial-tv.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Desporto TV ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-desporto.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Filmes PT ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-filmes-PT.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Filmes BR ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-filmes-br.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    },
    {
        "name": "[B][COLOR orange]Espada[/COLOR] [COLOR crimson]Negra[/COLOR][/B][COLOR orange] | [/COLOR]Series ",
        "url": "http://flechanegra.atspace.cc/addon--espadanegra/espadanegra-series.xml",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    }            
]